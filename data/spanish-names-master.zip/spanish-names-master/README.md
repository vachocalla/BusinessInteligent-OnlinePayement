##Lista de nombres y apellidos

Datos de frecuencia de nombres y apellidos en España en formato CSV.

Recogido de la base de datos del INE, de la página [Análisis y estudios demográficos](http://www.ine.es/daco/daco42/nombyapel/nombyapel.htm)

Contiene 4 archivos:

- `apellidos.csv` y `apellidos-20.csv`: Recopilado del "Fichero con todos los apellidos con frecuencia mayor o igual a 20 en el primer apellido." 
- `hombres.csv` y `mujeres.csv`: Recopilados del fichero "Nombres con frecuencia mayor o igual a 20 y sus edades medias"
